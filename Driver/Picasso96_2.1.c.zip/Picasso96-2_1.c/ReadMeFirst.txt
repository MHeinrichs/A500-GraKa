Picasso96 2.1 c

This is an unofficial alpha release of Picasso96 RTG system software that includes new additions and the last updates ever made, both official and some unofficial. Of course, as its status suggests, this is an alpha release, it has not been thoroughly tested, so everything is at your own risk.
It doesnt matter if you use an emulated enviroment or a real RTG graphics card, i highly recommend you give this distribution a try, as it should give you some improved RTG experience.

Note: In the specific case of Amithlon/AmigaOSXL drivers, these should be manually installed by the user. For details about the manual installation procedure, read the enclosed Picasso96 amigaguide document.

Good luck and enjoy!
 

Changelog:


New stuff: 

/Devs/monitors/powerfb 40.42 (Amithlon/AmigaOSXL monitor driver)
Powerfb.card 2.1 (Amithlon/AmigaOSXL graphics card driver)

Updated components:

/Prefs/PVS 3.0 -> 3.2
Picasso96API.library 2.300 -> 2.310
emulation.library 40.389 -> 40.395

CVision3D.card 6.281 -> 6.313
CyberVision.card 6.124 -> 6.136
Domino.card 6.67 - 6.77
Graffity.card 6.117 - 6.125
Merlin.card 6.180 -> 6.198
PicassoII.card 6.148 -> 6.158
PicassoIV.card 6.1093 -> 6.1118
Piccolo.card 6.114 -> 6.122
PiccoloSD64.card 6.118 -> 6.126
Pixel64.card 6.29 -> 6.41
Prometheus.card 6.81 -> 7.530
RetinaBLT.card 6.114 -> 6.131
Spectrum.card 6.121 -> 6.129
3dfxVoodoo.chip 6.412 -> 7.11
CirrusGD542X.chip 6.703 -> 6.727
CirrusGD5434.chip 6.131 -> 6.140
CirrusGD5446.chip 6.550 -> 6.572
NCR77C32BLT.chip 6.279 -> 6.290
S3Trio64.chip 6.534 -> 6.545
S3ViRGE.chip 6.430 -> 6.519
TsengET4000 6.108 -> 6.117
TsengET4000W32.chip 6.362 -> 6.372